const readline = require('readline');
const fs = require('fs');
const chalk = require("chalk");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const random = () => {
    return Math.floor(Math.random() * 10)
}

const generateCPFs = (base, quantity) => {

    function randomiza(n) {
        var ranNum = Math.round(Math.random()*n);
        return ranNum;
    }
    
    function mod(dividendo,divisor) {
        return Math.round(dividendo - (Math.floor(dividendo/divisor)*divisor));
    }

    comPontos = false; // TRUE para ativar e FALSE para desativar a pontuação.
    let quantidade = quantity;
    const lista = []
    var matriz = base;
    var i = 0
    for(;i < quantidade; i++){
    var n1 = matriz.charAt(0);
    var n2 = matriz.charAt(1);
    var n3 = matriz.charAt(2);
    var n4 = matriz.charAt(3);
    var n5 = matriz.charAt(4);
    var n6 = matriz.charAt(5);
    var n7 = matriz.charAt(6);
    var n8 = matriz.charAt(7);
    var n9 = matriz.charAt(8);
    var d1 = n9*2+n8*3+n7*4+n6*5+n5*6+n4*7+n3*8+n2*9+n1*10;
    d1 = 11 - ( mod(d1,11) );
    if (d1>=10) d1 = 0;
    var d2 = d1*2+n9*3+n8*4+n7*5+n6*6+n5*7+n4*8+n3*9+n2*10+n1*11;
    d2 = 11 - ( mod(d2,11) );
    if (d2>=10) d2 = 0;
    retorno = '';
    if (comPontos) cpf = ''+n1+n2+n3+'.'+n4+n5+n6+'.'+n7+n8+n9+'-'+d1+d2;
    else cpf = ''+n1+n2+n3+n4+n5+n6+n7+n8+n9+d1+d2;

    lista.push(cpf)
    var mm = parseInt(matriz);
    mm += 1000;
    matriz = mm.toString();
    matriz = matriz.padStart(11, "0");
    }
    return lista
}

const generateRandomCpfs = (quantity) => {
    function gerarCpf() {
        const n1 = aleatorio(), n2 = aleatorio(), n3 = aleatorio(), d1 = dig(n1, n2, n3);
        return `${n1}${n2}${n3}${d1}${dig(n1, n2, n3, d1)}`
    }
      
    function dig(n1, n2, n3, n4) { 
        let nums = n1.split("").concat(n2.split(""), n3.split("")), x = 0;    
        if (n4) nums[9] = n4;
        for (let i = (n4 ? 11:10), j = 0; i >= 2; i--, j++) x += parseInt(nums[j]) * i;
        return (y = x % 11) < 2 ? 0 : 11 - (y = x % 11); 
    }
    
    function aleatorio() {
    return ("" + Math.floor(Math.random() * 999)).padStart(3, '0'); 
    }
    const list = []
    for(var i = 0; i < quantity; i++) {
        list.push(gerarCpf())
    }
    return list
}


console.log(`
 ██████ ██████  ███████     ███████     ███████ ███████ ███    ██ ██   ██  █████       ██████  ███████ ███    ██ 
██      ██   ██ ██          ██          ██      ██      ████   ██ ██   ██ ██   ██     ██       ██      ████   ██ 
██      ██████  █████       █████       ███████ █████   ██ ██  ██ ███████ ███████     ██   ███ █████   ██ ██  ██ 
██      ██      ██          ██               ██ ██      ██  ██ ██ ██   ██ ██   ██     ██    ██ ██      ██  ██ ██ 
 ██████ ██      ██          ███████     ███████ ███████ ██   ████ ██   ██ ██   ██      ██████  ███████ ██   ████ 
                                                                                                                 
                                                                                                                 
`)

console.log(chalk.bgYellow("GERADOR DE CPF E SENHA FEITO POR JONATHAN - TODOS CPFS SÃO VALIDOS!"))
console.log(chalk.bgRed(""))


rl.question(`Você deseja gerar CPFs aleatórios ou com base em algum? \r\n [1] Aleatórios \r\n [2] Com base em matriz \r\n`, (answer) => {
	
    var matriz = false
    if(answer == 1) {
        rl.question(`Você deseja gerar quantos CPFs?: `, (quantity) => {
            if(parseInt(quantity) == NaN) {
                console.log('\x1b[31m', 'Quantidade invalida. Insira um número.')
                process.exit()
            }
            rl.question(`A senha terá quantos digitos? \r\n`, (digits) => {
    
                if (parseInt(digits) == NaN) {
                    console.log('\x1b[31m', `Ops... Quantidade invalida.`)
                    process.exit()
                } 
    
                rl.question(`Você deseja gerar senhas aleatorias ou usar os primeiros digitos do CPF? (usaremos os digitos do CPF, nesse cenário a senha só pode ter até 11 digitos.) \r\n  [1] Aleatórias \r\n [2] Usar digitos do CPF \r\n`, (answer) => {
                    
                    if(answer != 1 && answer != 2) {
                        console.log('\x1b[31m', `Ops... Opção invalida.`)
                        process.exit()
                    }
    
                    rl.question('Qual o nome do arquivo a ser gerado?: ', (file) => {
                        answer = parseInt(answer)  
                        file = `${file}.txt`
                        var cpfs = cpfs = generateRandomCpfs(quantity)
                        var list = ''
                        cpfs.map(cpf => {
                            var password = ''
                            if(answer == 2) password = cpf.substring(0, digits)
                            if(answer == 1) {
                                for(var i = 0; i < digits; i++) {
                                    password += `${random()}` 
                                }
                            }
                            list += `${cpf}|${password}\r\n`
                        })
                        fs.appendFile(file, list, () => {
                            console.log('\x1b[32m', `Arquivo gerado com sucesso!`)
                            process.exit()
                        })
                    })
                  
                })
                
            }) 
           
        })
    } else if(answer == 2) {
        rl.question(`Insira a matriz: `, (cpf) => {
            if(parseInt(cpf) == NaN || cpf.length != 11) {
                console.log('\x1b[31m', 'CPF inválido!')
                process.exit()
            }
            matriz = cpf

            rl.question(`Você deseja gerar quantos CPFs?: `, (quantity) => {
                if(parseInt(quantity) == NaN) {
                    console.log('\x1b[31m', 'Quantidade invalida. Insira um número.')
                    process.exit()
                }
                rl.question(`A senha terá quantos digitos?\r`, (digits) => {
        
                    if (parseInt(digits) == NaN) {
                        console.log('\x1b[31m', `Ops... Quantidade invalida.`)
                        process.exit()
                    } 
        
                    rl.question(`Você deseja gerar senhas aleatorias ou usar os primeiros digitos do CPF? (usaremos os digitos do CPF, nesse cenário a senha só pode ter até 11 digitos.) \r\n  [1] Aleatórias \r\n [2] Usar digitos do CPF \r\n`, (answer) => {
                        
                        if(answer != 1 && answer != 2) {
                            console.log('\x1b[31m', `Ops... Opção invalida.`)
                            process.exit()
                        }
        
                        rl.question('Qual o nome do arquivo a ser gerado?: ', (file) => {
                            answer = parseInt(answer)  
                            file = `${file}.txt`
                            var cpfs = generateCPFs(cpf, quantity)
                            var list = ''
                            cpfs.map(cpf => {
                                var password = ''
                                if(answer == 2) password = cpf.substring(0, digits)
                                if(answer == 1) {
                                    for(var i = 0; i < digits; i++) {
                                        password += `${random()}` 
                                    }
                                }
                                list += `${cpf}|${password}\r\n`
                            })
                            fs.appendFile(file, list, () => {
                                console.log('\x1b[32m', `Arquivo gerado com sucesso!`)
                                process.exit()
                            })
                        })
                      
                    })
                    
                }) 
               
            })
        })
    } else {
        console.log('\x1b[31m', 'Opção invalida!')
        process.exit()
    }

    
})
